
A simple blog built using following technologies.

1. ASP.NET MVC 4.0
2. NHibernate & Fluent NHibernate
3. SQL Server 2012
4. Ninject
5. jQuery

To know more, visit http://prideparrot.com/blog/archive/2012/12/how_to_create_a_simple_blog_part1.